void stdoutInit();
